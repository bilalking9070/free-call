const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, '../public')));

// users: { socketId -> { username, avatar, online } }
const users = {};

io.on('connection', (socket) => {

  socket.on('register', ({ username, avatar }) => {
    users[socket.id] = { username, avatar, socketId: socket.id, online: true };
    broadcastUsers();
  });

  socket.on('call-user', ({ to, offer, from }) => {
    const caller = users[socket.id];
    io.to(to).emit('incoming-call', { from: socket.id, callerName: caller?.username, callerAvatar: caller?.avatar, offer });
  });

  socket.on('call-answer', ({ to, answer }) => {
    io.to(to).emit('call-answered', { answer });
  });

  socket.on('ice-candidate', ({ to, candidate }) => {
    io.to(to).emit('ice-candidate', { candidate, from: socket.id });
  });

  socket.on('call-rejected', ({ to }) => {
    io.to(to).emit('call-rejected');
  });

  socket.on('call-ended', ({ to }) => {
    io.to(to).emit('call-ended');
  });

  socket.on('disconnect', () => {
    delete users[socket.id];
    broadcastUsers();
  });

  function broadcastUsers() {
    const list = Object.values(users);
    io.emit('users-list', list);
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`FreeCall server running on port ${PORT}`));
