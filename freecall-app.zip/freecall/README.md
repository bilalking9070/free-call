# 📞 FreeCall App — Bilkul Free Calling

## Kya hai yeh app?
- Doosron ko FREE internet call kar sakte hain
- Balance ki zaroorat NAHI
- Ek hi link pe sab aata hai
- WebRTC technology — bilkul WhatsApp jesi

## Setup kaise karein?

### Step 1 — Node.js install karein
https://nodejs.org se download karein (LTS version)

### Step 2 — Dependencies install karein
```bash
cd freecall
npm install
```

### Step 3 — Server chalayein
```bash
npm start
```

### Step 4 — Browser mein kholein
```
http://localhost:3000
```

### Step 5 — Doosron ko access dena
- Agar same WiFi pe hain: `http://[aapka-ip]:3000`
- Internet pe sab ko dena hai: Railway / Render pe deploy karein (free hai)

## Deploy karna (sab tak pahunchana)

### Railway (Recommended — Free):
1. https://railway.app pe account banayein
2. "Deploy from GitHub" chunein
3. Is folder ko upload karein
4. Aapko ek link milega jaise: `https://freecall-xxx.railway.app`
5. Yeh link sab dosto ko bhejein!

### Render (Alternative — Free):
1. https://render.com pe account banayein
2. New Web Service
3. `npm start` as start command
4. Deploy!

## Features
- ✅ Real voice calls (WebRTC)
- ✅ Online users list
- ✅ Call history
- ✅ Incoming call ringtone screen
- ✅ Mute / Speaker toggle
- ✅ End-to-End encryption (DTLS)
- ✅ Mobile friendly
- ✅ Bilkul FREE

## Technology
- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js + Express + Socket.IO
- **Calls**: WebRTC (browser built-in)
- **Signaling**: Socket.IO
